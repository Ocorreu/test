package lfb.fernandes.spinterface;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by fernandes on 21.11.2017.
 */

public class CreatePresetsActivity extends Activity implements View.OnClickListener{
    private EditText txtEditor;
    private String h;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_preset_activity);
        txtEditor = (EditText)findViewById(R.id.textbox);

        View createPreset = findViewById(R.id.btn_save);
        createPreset.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.btn_save:
                try {

                    h = DateFormat.format("yyyyMMdd-HHmmss", System.currentTimeMillis()).toString();
                    File root = new File(Environment.getExternalStorageDirectory(), "SP_Interface");
                    if (!root.exists()) {
                        root.mkdirs();
                    }
                    File filepath = new File(root, h + ".txt");
                    FileWriter writer = new FileWriter(filepath);
                    writer.append(txtEditor.getText().toString());
                    writer.flush();
                    writer.close();

                    Toast.makeText(getApplicationContext(), "File generated with name " + h + ".txt", Toast.LENGTH_SHORT).show();

                } catch (IOException e) {
                    e.printStackTrace();
                }

        }
    }

}