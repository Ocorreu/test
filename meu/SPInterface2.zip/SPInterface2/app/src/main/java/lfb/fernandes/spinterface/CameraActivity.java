package lfb.fernandes.spinterface;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.hardware.Camera;
import android.media.AudioManager;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.Toast;

import lfb.fernandes.spinterface.R;
import com.melnykov.fab.FloatingActionButton;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;

import butterknife.ButterKnife;
import butterknife.InjectView;

import static android.R.attr.bitmap;
import static android.R.attr.data;
import static lfb.fernandes.spinterface.Globals.protocol;
import static lfb.fernandes.spinterface.R.id.container;

/**
 * Created by fernandes on 11.10.2017.
 */

public class CameraActivity extends AppCompatActivity implements SurfaceHolder.Callback {
    Camera camera;

    @InjectView(R.id.surfaceView)
    SurfaceView surfaceView;
    SurfaceHolder surfaceHolder;
    Camera.PictureCallback jpegCallback;
    Camera.ShutterCallback shutterCallback;
    public int color_flag = 0;
    public String color_1 = "#0000FF";
    public String color_2 = "#00FF00";
    public String color_3 = "#00FFFF";
    public String color_4 = "#FF0000";
    public String color_5 = "#FF00FF";
    public String color_6 = "#FFFF00";
    public String color_7 = "#FFFFFF";
    public String color_8 = "#FFFFF0";
    public String color_9 = "#FFFF0F";

    public String wave_1 = "#610061";
    public String wave_2 = "#3D00FF";
    public String wave_3 = "#00D5FF";
    public String wave_4 = "#5EFF00";
    public String wave_5 = "#FFFF00";
    public String wave_6 = "#FF4F00";
    public String wave_7 = "#FF0000";
    public String wave_8 = "#C80000";
    public String wave_9 = "#610000";


    public String btn1 = null;
    public String btn3 = null;
    public String btn6 = null;
    public String btn9 = null;
    public String btncal = null;
    public String[] colorArray = null;

    public String[] colorFileColors = null;
    public int colorsLength = 0, colorsCount = 0;




    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.camera_activity);
        ButterKnife.inject(this);
        surfaceView = (SurfaceView) findViewById(R.id.surfaceView);

        Intent intent = getIntent();
        btn1 = intent.getStringExtra("btn1");
        btn3 = intent.getStringExtra("btn3");
        btn6 = intent.getStringExtra("btn6");
        btn9 = intent.getStringExtra("btn9");
        btncal = intent.getStringExtra("btncal");
        colorArray = intent.getStringArrayExtra("colorArray");


        surfaceHolder = surfaceView.getHolder();
        //Install a surfaceHolder.Callback so we get notified when the underlying surface is created and destroyed
        surfaceHolder.addCallback(this);
        //deprecated setting, but required on android versions prior to 3.0
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);

        //Sets brightness to max value
        WindowManager.LayoutParams layout = getWindow().getAttributes();
        layout.screenBrightness = 1;
        getWindow().setAttributes(layout);




        jpegCallback = new Camera.PictureCallback() {
            @Override
            public void onPictureTaken(byte[] data, Camera camera) {

                //takes care of rotation
                if(data != null) {

                    Bitmap bm = BitmapFactory.decodeByteArray(data, 0, (data != null) ? data.length : 0);


                    //TODO or not TODO, explore portrait vs landscape
               /*
                    int screenWidth = getResources().getDisplayMetrics().widthPixels;
                    int screenHeight = getResources().getDisplayMetrics().heightPixels;
                    if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
                        // Notice that width and height are reversed
                        Bitmap scaled = Bitmap.createScaledBitmap(bm, screenHeight, screenWidth, true);
                        int w = scaled.getWidth();
                        int h = scaled.getHeight();
                        // Setting post rotate to 90
                        Matrix mtx = new Matrix();
                        mtx.postRotate(90);
                        // Rotating Bitmap
                        bm = Bitmap.createBitmap(scaled, 0, 0, w, h, mtx, true);
                        Bitmap scaled = Bitmap.createScaledBitmap(bm, screenWidth,screenHeight , true);
                        bm=scaled;
                    }else{// LANDSCAPE MODE
                        //No need to reverse width and height
                        Bitmap scaled = Bitmap.createScaledBitmap(bm, screenWidth,screenHeight , true);
                        bm=scaled;
                    }
                */


                    FileOutputStream outputStream = null;
                    File file_image = getDirc();
                    if (!file_image.exists() && !file_image.mkdirs()) {
                        Toast.makeText(getApplicationContext(), "Can't create directory to save", Toast.LENGTH_LONG).show();
                        return;
                    }
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd-HHmmss");
                    String date = simpleDateFormat.format(new Date());
                    String photofile = "SP_Interface" + date + ".jpg";
                    String file_name = file_image.getAbsolutePath() + "/" + photofile;
                    File picfile = new File(file_name);
                    try {
                        Bitmap finalBitmap = rotate(bm,-90);
                        outputStream = new FileOutputStream(picfile);
                        finalBitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
                        outputStream.write(data);
                        outputStream.close();
                    } catch (FileNotFoundException e) {
                    } catch (IOException ex) {
                    } finally {

                    }
                    Toast.makeText(getApplicationContext(), "Picture saved", Toast.LENGTH_SHORT).show();
                    refreshCamera();
                    refreshGallery(picfile);
                }
            }
        };

    }


    public static Bitmap rotate(Bitmap source, float angle) {
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);

        return Bitmap.createBitmap(source, 0, 0, source.getWidth(),source.getHeight(), matrix, false);
    }

    private void refreshGallery(File file){
        Intent intent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        intent.setData(Uri.fromFile(file));
        sendBroadcast(intent);
    }

    public void refreshCamera(){
        if(surfaceHolder.getSurface()==null){
            //preview surface does not exist
            return;
        }
        //stop preview before making changes
        try {
            camera.stopPreview();
        } catch (Exception e) {
        }
        //set preview size and make any resize, rotate or reformatting changes here. Start preview with new settings
        try{
            camera.setPreviewDisplay(surfaceHolder);
            camera.startPreview();
        }catch (Exception e){}
    }

    private File getDirc(){
        File dics = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
        return new File(dics,"SP_Interface");
    }

    public void cameraImage(){
        //take the picture
        camera.takePicture(null,null,jpegCallback);
    }

    @Override
    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        //open the FRONT camera
        try {
            camera = Camera.open(1);
        } catch (RuntimeException ex) {

        }

        Camera.Parameters parameters;
        parameters = camera.getParameters();
        //modify parameter
        parameters.setPreviewFrameRate(20);
        parameters.setPreviewSize(352,288);
        camera.setParameters(parameters);
        camera.setDisplayOrientation(90);
        try{
            //The surface has been created, now tell the camera where to draw the preview
            camera.setPreviewDisplay(surfaceHolder);
            camera.startPreview();
            if(Globals.connected == true) {
                Threadrun();
            }
        }catch(Exception e){}

    }

    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {
        refreshCamera();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        //stop preview and release the camera
        camera.stopPreview();
        camera.release();
        camera=null;
    }

    //Volume up changes to next color
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        super.onKeyDown(keyCode, event);


        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            if(!colorArray[0].equals("0") && colorArray.length != colorsCount) {
               // Toast.makeText(getApplicationContext(), colorArray[0],Toast.LENGTH_SHORT).show();
                surfaceView.setBackgroundColor(Color.parseColor(colorArray[colorsCount]));
                colorsCount++;
            }else {
                if(colorArray[0].equals("0")) {
                    switch (color_flag) {
                        case 0:
                            color_flag += 1;
                            if (btncal.equals("1")) {
                                surfaceView.setBackgroundColor(Color.parseColor(wave_1));
                            } else {
                                Toast.makeText(getApplicationContext(), color_flag + " - " + color_1, Toast.LENGTH_SHORT).show();
                                surfaceView.setBackgroundColor(Color.parseColor(color_1));
                            }
                            if (btn1.equals("1")) {
                                color_flag = 9;
                            }

                            break;
                        case 1:
                            color_flag += 1;
                            if (btncal.equals("1")) {
                                surfaceView.setBackgroundColor(Color.parseColor(wave_2));
                            } else {
                                Toast.makeText(getApplicationContext(), color_flag + " - " + color_2, Toast.LENGTH_SHORT).show();
                                surfaceView.setBackgroundColor(Color.parseColor(color_2));
                            }
                            break;
                        case 2:
                            color_flag += 1;
                            if (btncal.equals("1")) {
                                surfaceView.setBackgroundColor(Color.parseColor(wave_3));
                            } else {
                                Toast.makeText(getApplicationContext(), color_flag + " - " + color_3, Toast.LENGTH_SHORT).show();
                                surfaceView.setBackgroundColor(Color.parseColor(color_3));
                            }
                            if (btn3.equals("1")) {
                                color_flag = 9;
                            }
                            break;
                        case 3:
                            color_flag += 1;
                            if (btncal.equals("1")) {
                                surfaceView.setBackgroundColor(Color.parseColor(wave_4));
                            } else {
                                Toast.makeText(getApplicationContext(), color_flag + " - " + color_4, Toast.LENGTH_SHORT).show();
                                surfaceView.setBackgroundColor(Color.parseColor(color_4));
                            }
                            break;
                        case 4:
                            color_flag += 1;
                            if (btncal.equals("1")) {
                                surfaceView.setBackgroundColor(Color.parseColor(wave_5));
                            } else {
                                Toast.makeText(getApplicationContext(), color_flag + " - " + color_5, Toast.LENGTH_SHORT).show();
                                surfaceView.setBackgroundColor(Color.parseColor(color_5));
                            }
                            break;
                        case 5:
                            color_flag += 1;
                            if (btncal.equals("1")) {
                                surfaceView.setBackgroundColor(Color.parseColor(wave_6));
                            } else {
                                Toast.makeText(getApplicationContext(), color_flag + " - " + color_6, Toast.LENGTH_SHORT).show();
                                surfaceView.setBackgroundColor(Color.parseColor(color_6));
                            }
                            if (btn6.equals("1")) {
                                color_flag = 9;
                            }
                            break;
                        case 6:
                            color_flag += 1;
                            if (btncal.equals("1")) {
                                surfaceView.setBackgroundColor(Color.parseColor(wave_7));
                            } else {
                                Toast.makeText(getApplicationContext(), color_flag + " - " + color_7, Toast.LENGTH_SHORT).show();
                                surfaceView.setBackgroundColor(Color.parseColor(color_7));
                            }
                            break;
                        case 7:
                            color_flag += 1;
                            if (btncal.equals("1")) {
                                surfaceView.setBackgroundColor(Color.parseColor(wave_8));
                            } else {
                                Toast.makeText(getApplicationContext(), color_flag + " - " + color_8, Toast.LENGTH_SHORT).show();
                                surfaceView.setBackgroundColor(Color.parseColor(color_8));
                            }
                            break;
                        case 8:
                            color_flag += 1;
                            if (btncal.equals("1")) {
                                surfaceView.setBackgroundColor(Color.parseColor(wave_9));
                            } else {
                                Toast.makeText(getApplicationContext(), color_flag + " - " + color_9, Toast.LENGTH_SHORT).show();
                                surfaceView.setBackgroundColor(Color.parseColor(color_9));
                            }
                            if (btn9.equals("1")) {
                                color_flag = 9;
                            }
                            break;
                        default:
                            Toast.makeText(getApplicationContext(), "All colours used", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplication(), MainActivity.class);
                            startActivity(intent);
                    }
                }else{
                    Toast.makeText(getApplicationContext(), "All colours used", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplication(), MainActivity.class);
                    startActivity(intent);
                }
            }
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            camera.takePicture(null, null, jpegCallback);
            return true;
        }

        return false;
    }

    public void ChangeColor(String color) {
        surfaceView.setBackgroundColor(Color.parseColor(color));
    }

    public void Threadrun() {

            new Thread() {
                @Override
                public void run() {
                    String data = null;

                    while(Globals.connected) {
                        Globals.outputLine = protocol.processInput(null);
                        Globals.socketOut.println(Globals.outputLine);
                        try {
                            while ((Globals.inputLine = Globals.socketIn.readLine()) != null) {
                                    try {

                                        runOnUiThread(new Runnable() {

                                            @Override
                                            public void run() {
                                                if (Globals.inputLine.equals("END")) {
                                                    Globals.socketOut.println("ENDED");
                                                    Toast.makeText(getApplicationContext(), "Calibration finished", Toast.LENGTH_SHORT).show();
                                                    Intent intent = new Intent(getApplication(), MainActivity.class);
                                                    startActivity(intent);
                                                }
                                                else {
                                                    ChangeColor(Globals.inputLine);
                                                    Globals.outputLine = protocol.processInput(Globals.inputLine);
                                                    Globals.socketOut.println(Globals.outputLine);
                                                }
                                            }
                                        });
                                        Thread.sleep(5000);
                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                    }
                                    //ChangeColor(Globals.inputLine); NEEDS TO CHANGE THE COLOUR HERE


                            }
                        }catch(IOException ioe){
                            ioe.printStackTrace();
                        }
                    }
                }
            }.start();
    }
}

