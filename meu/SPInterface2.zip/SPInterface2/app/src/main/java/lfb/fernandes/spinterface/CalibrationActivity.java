package lfb.fernandes.spinterface;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.sql.Connection;
import java.util.Scanner;

/**
 * Created by fernandes on 13.11.2017.
 */

public class CalibrationActivity extends Activity implements View.OnClickListener {

    public static final String TAG="Connection";

    public static final int TIMEOUT=10;

    private Intent i = null;
    private TextView tv = null;
    private String connectionStatus = null;
    private android.os.Handler mHandler = null;
    private ServerSocket server = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.connection);

        //Set up click listener for the Connect button
        View connectButton = findViewById(R.id.connect_button);
        connectButton.setOnClickListener(this);

        this.i = new Intent(this, CameraActivity.class);
        this.mHandler = new android.os.Handler();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.connect_button:
                //initialize server socket in a new separate thread
                new Thread(initializeConnection).start();
                String msg = "Attempting to connect ...";
                Toast.makeText(CalibrationActivity.this, msg, Toast.LENGTH_LONG).show();
                break;
        }
    }

    //openning the socket
    private Runnable initializeConnection = new Thread() {

        public void run() {

            Socket client=null;
            // initialize server socket
            try{
                server = new ServerSocket(1234);
                server.setSoTimeout(TIMEOUT * 2000);

                Log.d(TAG, "Waiting for connection.");
                //attempt to accept a connection
                client = server.accept();
                Log.d(TAG, "Accepted");

                //opens the scanner and the printer in the socket -- sets it as global
                Globals.socketIn = new BufferedReader(new InputStreamReader(client.getInputStream()));
                Globals.socketOut = new PrintWriter(client.getOutputStream(), true);
                Globals.protocol = new Protocol();
            } catch (SocketTimeoutException e) {
                // print out TIMEOUT
                connectionStatus="Connection has timed out! Please try again";
                mHandler.post(showConnectionStatus);
                Log.d(TAG, "Connection timeout");
            } catch (IOException e) {
                Log.e(TAG, "" + e);
            } finally {

                //close the server socket
                try {
                    if (server!=null)
                        Log.d(TAG, "Closing server");
                    server.close();
                } catch (IOException ec) {
                    Log.e(TAG, "Cannot close server socket" + ec);
                }
            }

            if (client!=null) {

                Globals.connected = true;
                // print out success
                connectionStatus="Connection was successful!";
                mHandler.post(showConnectionStatus);

                startActivity(i);
            }
        }
    };

    /**
     * Pops up a “toast” to indicate the connection status
     */
    private Runnable showConnectionStatus = new Runnable() {
        public void run() {
            Toast.makeText(CalibrationActivity.this, connectionStatus, Toast.LENGTH_SHORT).show();
        }
    };
}
