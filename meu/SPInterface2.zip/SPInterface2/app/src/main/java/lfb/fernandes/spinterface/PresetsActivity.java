package lfb.fernandes.spinterface;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import butterknife.OnClick;

/**
 * Created by fernandes on 13.11.2017.
 */

public class PresetsActivity extends Activity implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    private Spinner sp;
    private StringBuilder text = new StringBuilder();
    public String content = null;
    public String[] colorArray = null;
    public int counter = 0;
    List<String> temps = new ArrayList<String>();
    Button createPreset, usePreset;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.presets_activity);

        createPreset = (Button) findViewById(R.id.create_preset_btn);
        usePreset = (Button) findViewById(R.id.use_btn);

        createPreset.setOnClickListener(this);
        usePreset.setOnClickListener(this);

        File root = new File(Environment.getExternalStorageDirectory(), "SP_Interface");
        File[] listOfFiles = root.listFiles();
        String[] fileNames = new String[listOfFiles.length];

        for (int i = 0; i < listOfFiles.length; i++) {
            fileNames[i] = listOfFiles[i].getName();
        }

        sp = findViewById(R.id.spinner);
        sp.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,fileNames));
        sp.setOnItemSelectedListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.create_preset_btn:
                Intent intent = new Intent(getApplication(), CreatePresetsActivity.class);
                startActivity(intent);
            case R.id.use_btn:
                Intent intent2 = new Intent(getApplication(), CameraActivity.class);
                intent2.putExtra("btn1","0");
                intent2.putExtra("btn3","0");
                intent2.putExtra("btn6","0");
                intent2.putExtra("btn9","0");
                intent2.putExtra("btncal", "0");
                intent2.putExtra("colorArray", colorArray);
                startActivity(intent2);
        }
    }

    public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
        final TextView selectedFile = (TextView) findViewById(R.id.mytextview);
        content = sp.getSelectedItem().toString();
        File textViewContent = new File(Environment.getExternalStorageDirectory(), "SP_Interface/" + content);

        BufferedReader reader = null;

        try {
            reader = new BufferedReader(new InputStreamReader(new FileInputStream(textViewContent)));
            text.setLength(0);
            temps.clear();
            // do reading, usually loop until end of file reading
            String mLine;
            while ((mLine = reader.readLine()) != null) {
                text.append(mLine);
                text.append('\n');
                temps.add(mLine);

            }
            colorArray = temps.toArray(new String[0]);

        } catch (IOException e) {
            Toast.makeText(getApplicationContext(),"Error reading file!",Toast.LENGTH_LONG).show();
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    //log the exception
                }
            }
        }
        selectedFile.setText( text);
        Toast.makeText(getApplicationContext(), content + " is selected.", Toast.LENGTH_SHORT).show();

    }

    public void onNothingSelected(AdapterView<?> parent) {
        // Another interface callback
    }

}
