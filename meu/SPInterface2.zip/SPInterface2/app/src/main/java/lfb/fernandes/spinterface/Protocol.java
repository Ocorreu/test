package lfb.fernandes.spinterface;

/**
 * Created by fernandes on 13.11.2017.
 */

class Protocol {

    String processInput(String theInput) {
        String theOutput = null;
        if(theInput != null) {
            //change color here
            //theInput contains color
            //theOutput confirms the color change
            theOutput = "Color changed to " + theInput;
            return theOutput;
        } else {
            theOutput = "READY";
            return theOutput;
        }

    }
}