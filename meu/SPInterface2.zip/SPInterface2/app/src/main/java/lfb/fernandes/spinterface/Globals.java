package lfb.fernandes.spinterface;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * Created by Fernandes on 07.11.2017.
 */

public class Globals {
    public static boolean connected = false;
    public static BufferedReader socketIn;
    public static PrintWriter socketOut;
    public static Protocol protocol;
    public static String inputLine;
    public static String outputLine;
}
