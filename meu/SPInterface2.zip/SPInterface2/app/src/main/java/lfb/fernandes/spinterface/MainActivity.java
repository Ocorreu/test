package lfb.fernandes.spinterface;

import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.io.File;

import lfb.fernandes.spinterface.R;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class MainActivity extends AppCompatActivity {
    public static final int IMAGE_GALLERY_REQUEST = 20;
    @InjectView(R.id.btn_1)
    Button btn_1;
    @InjectView(R.id.btn_3)
    Button btn_3;
    @InjectView(R.id.btn_6)
    Button btn_6;
    @InjectView(R.id.btn_9)
    Button btn_9;
    @InjectView(R.id.btn_cal)
    Button btn_cal;
    @InjectView(R.id.btn_transfer)
    Button btn_transfer;
    //@InjectView(R.id.btn_gallery)
    //Button btn_gallery;
    @InjectView(R.id.btn_presets)
    Button btn_presets;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.inject(this);
        btn_1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(getApplication(),CameraActivity.class);
                intent.putExtra("btn1","1");
                intent.putExtra("btn3","0");
                intent.putExtra("btn6","0");
                intent.putExtra("btn9","0");
                intent.putExtra("btncal", "0");
                intent.putExtra("colorArray", "0");
                startActivity(intent);
            }
        });
        btn_3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(getApplication(),CameraActivity.class);
                intent.putExtra("btn1","0");
                intent.putExtra("btn3","1");
                intent.putExtra("btn6","0");
                intent.putExtra("btn9","0");
                intent.putExtra("btncal", "0");
                intent.putExtra("colorArray", "0");
                startActivity(intent);
            }
        });
        btn_6.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(getApplication(),CameraActivity.class);
                intent.putExtra("btn1","0");
                intent.putExtra("btn3","0");
                intent.putExtra("btn6","1");
                intent.putExtra("btn9","0");
                intent.putExtra("btncal", "0");
                intent.putExtra("colorArray", "0");
                startActivity(intent);
            }
        });
        btn_9.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(getApplication(),CameraActivity.class);
                intent.putExtra("btn1","0");
                intent.putExtra("btn3","0");
                intent.putExtra("btn6","0");
                intent.putExtra("btn9","1");
                intent.putExtra("btncal", "0");
                intent.putExtra("colorArray", "0");
                startActivity(intent);
            }
        });
        btn_cal.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(getApplication(),CalibrationActivity.class);
                startActivity(intent);
            }
        });
        btn_transfer.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(getApplication(),TransferGalleryActivity.class);

                startActivity(intent);
            }

        });
        btn_presets.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(getApplication(),PresetsActivity.class);

                startActivity(intent);
            }

        });
      /*  btn_gallery.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(getApplication(),GalleryActivity.class);
                startActivity(intent);
            }

        });*/
    }

    //When gallery in camera is clicked
    public void cameraGalleryClicked(View v) {
        //invoke the image gallery using implicit intent
        Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);

        File pictureDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        String pictureDirectoryPath = pictureDirectory.getPath();
        //get URI representation
        Uri data = Uri.parse(pictureDirectoryPath);

        //set data and type
        photoPickerIntent.setDataAndType(data, "image/jpeg");

        startActivityForResult(photoPickerIntent, IMAGE_GALLERY_REQUEST);

    }
}