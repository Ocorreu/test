package com.haresh.multipleimagepickerlibrary.listeners;


import com.haresh.multipleimagepickerlibrary.models.Folder;

public interface FolderOnItemClickListener {
    void folderOnItemClick(int position, Folder folder);
}
