package com.haresh.multipleimagepickerlibrary.listeners;


import com.haresh.multipleimagepickerlibrary.models.Image;

public interface ImageOnItemClickListener {
    void imageOnItemClick(int position, Image folder);
}
